TEXT = {
    'ru': {
        'heading': 'Проверьте данные заявки:',
        'labels': ['Тур или направление', 'Дата поездки', 'Количество гостей', 'Имя',
                   'Телефон', 'Email', 'Продолжительность (дней)', 'Бюджет', 'Пожелания и размещение'],
        'missing': 'не указан',
        'confirm': ('Это заявка менеджеру, а не окончательная бронь. '
                    'Подтверждаете отправку заявки менеджеру? '
                    'Чтобы отправить заявку, напишите: «Я готова бронировать тур» '
                    'или «Я готов бронировать тур». Короткое «да» заявку не отправляет. '
                    'Для отказа напишите «Не отправляйте заявку», для исправлений укажите изменения.'),
        'declined': 'Заявка не отправлена. Что хотите изменить или уточнить?',
        'submitted': ('Ваши данные переданы менеджеру KYRGYZGO. Он скоро свяжется с вами '
                      'для уточнения деталей и подтверждения бронирования. '
                      'Номер заявки: {request_id}.'),
    },
    'en': {
        'heading': 'Please review your request:',
        'labels': ['Tour or destination', 'Travel date', 'Guests', 'Name', 'Phone',
                   'Email', 'Duration (days)', 'Budget', 'Preferences and accommodation'],
        'missing': 'not specified',
        'confirm': ('This is a request to a manager, not a confirmed booking. '
                    'To submit it, write "I confirm". A plain "yes" does not submit it. '
                    'Write "Do not submit" to decline, or tell me what to change.'),
        'declined': 'Your request has not been sent. What would you like to change or clarify?',
        'submitted': ('Request #{request_id} has been sent to a KYRGYZGO manager. '
                      'The manager will contact you soon to clarify the details and confirm your booking.'),
    },
    'ky': {
        'heading': 'Өтүнмөнүн маалыматтарын текшериңиз:',
        'labels': ['Тур же багыт', 'Сапардын датасы', 'Коноктордун саны', 'Аты', 'Телефон',
                   'Email', 'Узактыгы (күн)', 'Бюджет', 'Каалоолор жана жайгашуу'],
        'missing': 'көрсөтүлгөн эмес',
        'confirm': ('Бул менеджерге өтүнмө, акыркы брондоо эмес. Жөнөтүү үчүн «Ырастайм» деп жазыңыз. '
                    'Жөн гана «ооба» өтүнмөнү жөнөтпөйт. Баш тартуу үчүн «Жөнөтпө» деп жазыңыз '
                    'же эмнени өзгөртүү керектигин айтыңыз.'),
        'declined': 'Өтүнмө жөнөтүлгөн жок. Эмнени өзгөрткүңүз же тактагыңыз келет?',
        'submitted': ('№{request_id} өтүнмө KYRGYZGO менеджерине жөнөтүлдү. Менеджер маалыматтарды '
                      'тактоо жана брондоону ырастоо үчүн жакында сиз менен байланышат.'),
    },
    'de': {
        'heading': 'Bitte prüfen Sie Ihre Anfrage:',
        'labels': ['Tour oder Reiseziel', 'Reisedatum', 'Personen', 'Name', 'Telefon',
                   'E-Mail', 'Dauer (Tage)', 'Budget', 'Wünsche und Unterkunft'],
        'missing': 'nicht angegeben',
        'confirm': ('Dies ist eine Anfrage an das Team, keine bestätigte Buchung. '
                    'Schreiben Sie "Ich bestätige", um sie abzusenden. Ein einfaches "Ja" genügt nicht. '
                    'Mit "Nicht absenden" lehnen Sie ab; Änderungen können Sie direkt mitteilen.'),
        'declined': 'Ihre Anfrage wurde nicht gesendet. Was möchten Sie ändern oder klären?',
        'submitted': ('Anfrage Nr. {request_id} wurde an das KYRGYZGO-Team gesendet. '
                      'Das Team wird Sie bald kontaktieren, um die Details zu klären und Ihre Buchung zu bestätigen.'),
    },
    'zh': {
        'heading': '请核对申请信息：',
        'labels': ['行程或目的地', '出行日期', '人数', '姓名', '电话', '邮箱', '行程天数', '预算', '住宿及其他需求'],
        'missing': '未提供',
        'confirm': ('这是提交给客服的申请，并非已确认的预订。请回复“确认提交”发送申请，'
                    '单独回复“是”不会提交。取消请回复“不发送”，也可以说明需要修改的信息。'),
        'declined': '申请尚未发送。您希望修改或确认哪些信息？',
        'submitted': ('申请编号 {request_id} 已发送给 KYRGYZGO 客服。'
                      '客服会尽快联系您，核实详细信息并确认预订。'),
    },
}


def booking_text(data):
    language = data.get('language', 'ru')
    return TEXT.get(language, TEXT['en'])


def preview_text(data, choice):
    text = booking_text(data)
    values = [choice, data['travel_date'], data['people_count'], data['client_name'], data['phone'],
              data.get('email'), data.get('duration_days'), data.get('budget'), data.get('notes')]
    lines = [f'{label}: {value if value is not None and value != "" else text["missing"]}'
             for label, value in zip(text['labels'], values)]
    return '\n\n' + text['heading'] + '\n' + '\n'.join(lines) + '\n\n' + text['confirm']
